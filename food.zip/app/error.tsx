"use client";

export default function ErrorPage() {
  return <div>ErrorPage</div>;
}
